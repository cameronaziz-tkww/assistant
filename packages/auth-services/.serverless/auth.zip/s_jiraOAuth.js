
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'tkwwassistant',
  applicationName: 'auth',
  appUid: 'hdNSyQvfDMQ4LHbKpS',
  orgUid: '915a564f-52c3-49e7-9b40-6e89aac52be4',
  deploymentUid: 'db77c670-eaa9-4429-be49-7c1e77986cb0',
  serviceName: 'auth',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'auth-dev-jiraOAuth', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.jiraOAuth, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}