"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GITHUB_CLIENT_SECRET = exports.GITHUB_CLIENT_ID = exports.GITHUB_APP_ID = exports.GITHUB_CLIENT = exports.JIRA_CLIENT = exports.JIRA_APP_ID = exports.GIT_TOKEN = void 0;
exports.GIT_TOKEN = 'e904b370eaf4f59567442f72ac0e123e51859b97';
exports.JIRA_APP_ID = '7a8a9978-ab14-47e2-9112-8454a7ff5924';
exports.JIRA_CLIENT = {
    client_id: '98FCios0XpJ23YoEHJxy2vPaJrJzzvmp',
    client_secret: 'v6VZbteFoaDLGBnA0ykbrM5MBe2SzTFvPCtguBQEBQdibUj6oYcVM1PSfCQxFZgp',
};
exports.GITHUB_CLIENT = {
    client_id: '092bb99b2a1d97d76493',
    client_secret: '6e8f24c7ae32fb921fd3ae26a2d7fe3263c3ce7c',
};
exports.GITHUB_APP_ID = '105520';
exports.GITHUB_CLIENT_ID = '092bb99b2a1d97d76493';
exports.GITHUB_CLIENT_SECRET = '6e8f24c7ae32fb921fd3ae26a2d7fe3263c3ce7c';
//# sourceMappingURL=settings.js.map