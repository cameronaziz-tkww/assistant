"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var fourOhFour = function (functionName, failed) { return ({
    statusCode: 404,
    body: JSON.stringify({ functionName: functionName, failed: failed }),
}); };
exports.default = fourOhFour;
//# sourceMappingURL=fourOhFour.js.map